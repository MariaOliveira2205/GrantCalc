package com.grantcalc.calculation;

public class GenericPenaltyDecorator extends GrantDecorator {
    private String penaltyName;
    private double amount;

    public GenericPenaltyDecorator(Grant decoratedGrant, String penaltyName, double amount) {
        super(decoratedGrant);
        this.penaltyName = penaltyName;
        this.amount = amount;
    }

    @Override
    public double calculateTotal() {
        return super.calculateTotal() - amount;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "\n- " + penaltyName + ": R$" + amount;
    }
}
