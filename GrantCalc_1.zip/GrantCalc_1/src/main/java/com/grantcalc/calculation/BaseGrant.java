package com.grantcalc.calculation;

public class BaseGrant implements Grant {
    private double baseGrantAmount;

    public BaseGrant(double baseGrantAmount) {
        this.baseGrantAmount = baseGrantAmount;
    }

    @Override
    public double calculateTotal() {
        return baseGrantAmount;
    }

    @Override
    public String getDescription() {
        return "Valor base da bolsa: R$" + baseGrantAmount;
    }
}
