package com.grantcalc.calculation;

public class ChildcareAidDecorator extends GrantDecorator {
    private double amount;

    public ChildcareAidDecorator(Grant grant, double amount) {
        super(grant);
        this.amount = amount;
    }

    @Override
    public double calculateTotal() {
        return super.calculateTotal() + amount;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + Auxilio Creche: (" + amount + ")";
    }
}
