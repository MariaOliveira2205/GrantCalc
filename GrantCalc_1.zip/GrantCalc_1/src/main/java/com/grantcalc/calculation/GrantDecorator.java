package com.grantcalc.calculation;

public abstract class GrantDecorator implements Grant {
    protected Grant decoratedGrant;

    public GrantDecorator(Grant decoratedGrant) {
        this.decoratedGrant = decoratedGrant;
    }

    @Override
    public double calculateTotal() {
        return decoratedGrant.calculateTotal();
    }

    @Override
    public String getDescription() {
        return decoratedGrant.getDescription();
    }
}
