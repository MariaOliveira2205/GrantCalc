package com.grantcalc.calculation;

public class LibraryFineDecorator extends GrantDecorator {
    private double amount;

    public LibraryFineDecorator(Grant grant, double amount) {
        super(grant);
        this.amount = amount;
    }

    @Override
    public double calculateTotal() {
        return super.calculateTotal() - amount;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " - Multa Biblioteca (" + amount + ")";
    }
}
