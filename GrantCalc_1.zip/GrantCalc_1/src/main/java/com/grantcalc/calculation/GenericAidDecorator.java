package com.grantcalc.calculation;

public class GenericAidDecorator extends GrantDecorator {
    private String benefitName;
    private double amount;

    public GenericAidDecorator(Grant decoratedGrant, String benefitName, double amount) {
        super(decoratedGrant);
        this.benefitName = benefitName;
        this.amount = amount;
    }

    @Override
    public double calculateTotal() {
        return super.calculateTotal() + amount;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "\n+ " + benefitName + ": R$" + amount;
    }
}
