package com.grantcalc.calculation;

public class AthleteGrantDecorator extends GrantDecorator {
    private double amount;

    public AthleteGrantDecorator(Grant grant, double amount) {
        super(grant);
        this.amount = amount;
    }

    @Override
    public double calculateTotal() {
        return super.calculateTotal() + amount;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + Bolsa Atleta (" + amount + ")";
    }
}
