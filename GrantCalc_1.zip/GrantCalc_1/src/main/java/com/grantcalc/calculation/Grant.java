package com.grantcalc.calculation;

public interface Grant {
    double calculateTotal();
    String getDescription();
}
