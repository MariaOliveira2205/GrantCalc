package com.grantcalc.calculation;

public class FoodAidDecorator extends GrantDecorator {
    private double amount;

    public FoodAidDecorator(Grant grant, double amount) {
        super(grant);
        this.amount = amount;
    }

    @Override
    public double calculateTotal() {
        return super.calculateTotal() + amount;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + Alimentação (" + amount + ")";
    }
}
