package com.grantcalc.calculation;

public class HousingAidDecorator extends GrantDecorator {
    private double amount;

    public HousingAidDecorator(Grant grant, double amount) {
        super(grant);
        this.amount = amount;
    }

    @Override
    public double calculateTotal() {
        return super.calculateTotal() + amount;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + Auxilio Moradia (" + amount + ")";
    }
}
