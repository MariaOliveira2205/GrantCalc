package com.grantcalc.calculation;

public class TransportAidDecorator extends GrantDecorator {
    private double amount;

    public TransportAidDecorator(Grant grant, double amount) {
        super(grant);
        this.amount = amount;
    }

    @Override
    public double calculateTotal() {
        return super.calculateTotal() + amount;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + Auxílio Transporte (" + amount + ")";
    }
}
