package com.grantcalc.repository;

import com.grantcalc.model.Benefit;
import com.grantcalc.model.BenefitType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface BenefitRepository extends JpaRepository<Benefit, Long> {
    Optional<Benefit> findByType(BenefitType type);
}
