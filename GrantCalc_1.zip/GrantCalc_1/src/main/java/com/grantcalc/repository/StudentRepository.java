package com.grantcalc.repository;

import com.grantcalc.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {
    Optional<Student> findByRegistrationNumber(String registrationNumber);

    // Filtros adicionais
    List<Student> findByRegistrationNumberContaining(String registrationNumber);
    List<Student> findByBaseGrantAmountGreaterThan(Double amount);
    List<Student> findByBaseGrantAmountLessThan(Double amount);
}
