package com.grantcalc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrantCalcApplication {

    public static void main(String[] args) {
        SpringApplication.run(GrantCalcApplication.class, args);
    }
}
