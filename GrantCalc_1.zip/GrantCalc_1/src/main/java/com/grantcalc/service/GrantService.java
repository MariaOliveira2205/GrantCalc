package com.grantcalc.service;

import com.grantcalc.calculation.*;
import com.grantcalc.model.Student;
import com.grantcalc.model.StudentBenefit;
import com.grantcalc.model.Benefit;
import com.grantcalc.model.BenefitType;
import com.grantcalc.repository.StudentRepository;
import com.grantcalc.repository.BenefitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GrantService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private BenefitRepository benefitRepository;

    // Método principal: monta o cálculo da bolsa
    public Grant buildGrantForStudent(String registrationNumber) {
        Student student = studentRepository.findByRegistrationNumber(registrationNumber)
                                           .orElseThrow(() -> new IllegalArgumentException("Matrícula não encontrada"));

        Grant grant = new BaseGrant(student.getBaseGrantAmount());

        for (StudentBenefit sb : student.getBenefits()) {
            Benefit b = sb.getBenefit();

            switch (b.getType()) {
                case HOUSING:
                    grant = new HousingAidDecorator(grant, b.getAmount());
                    break;
                case TRANSPORT:
                    grant = new TransportAidDecorator(grant, b.getAmount());
                    break;
                case FOOD:
                    grant = new FoodAidDecorator(grant, b.getAmount());
                    break;
                case CHILDCARE:
                    grant = new ChildcareAidDecorator(grant, b.getAmount());
                    break;
                case LIBRARY_FINE:
                    grant = new LibraryFineDecorator(grant, b.getAmount());
                    break;
                case ATHLETE:
                    grant = new AthleteGrantDecorator(grant, b.getAmount());
                    break;
            }
        }

        return grant;
    }

    // Novo método auxiliar: vincula benefícios ao aluno
    public void attachBenefits(Student student, List<String> benefits) {
        for (String b : benefits) {
            Benefit benefit = new Benefit();
            benefit.setName(b);
            benefit.setType(BenefitType.valueOf(b));
            benefit.setAmount(definirValorPadrao(b));

            benefitRepository.save(benefit);

            StudentBenefit sb = new StudentBenefit();
            sb.setStudent(student);
            sb.setBenefit(benefit);

            student.getBenefits().add(sb);
        }
    }

    private double definirValorPadrao(String benefitType) {
        switch (benefitType) {
            case "HOUSING": return 300.0;
            case "TRANSPORT": return 150.0;
            case "FOOD": return 250.0;
            case "CHILDCARE": return 400.0;
            case "ATHLETE": return 200.0;
            case "LIBRARY_FINE": return 25.0;
            default: return 0.0;
        }
    }
}
