package com.grantcalc.controller;

import com.grantcalc.model.Student;
import com.grantcalc.model.Benefit;
import com.grantcalc.model.BenefitType;
import com.grantcalc.model.StudentBenefit;
import com.grantcalc.repository.StudentRepository;
import com.grantcalc.repository.BenefitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private BenefitRepository benefitRepository;

    // LISTAR todos os alunos com filtros
    @GetMapping
    public String listStudents(@RequestParam(required = false) String registrationNumber,
                               @RequestParam(required = false) Double baseGrantAmount,
                               @RequestParam(required = false) String benefit,
                               Model model) {

        List<Student> students;

        if (registrationNumber != null && !registrationNumber.isEmpty()) {
            students = studentRepository.findByRegistrationNumberContaining(registrationNumber);
        } else if (baseGrantAmount != null) {
            students = studentRepository.findByBaseGrantAmountGreaterThan(baseGrantAmount);
        } else {
            students = studentRepository.findAll();
        }

        // Filtro por benefício (feito em memória)
        if (benefit != null && !benefit.isEmpty()) {
            students = students.stream()
                    .filter(s -> s.getBenefits().stream()
                            .anyMatch(sb -> sb.getBenefit().getType().name().equals(benefit)))
                    .toList();
        }

        model.addAttribute("students", students);
        return "students"; // página students.html
    }

    // FORMULÁRIO de nova matrícula
    @GetMapping("/new")
    public String newStudentForm(Model model) {
        model.addAttribute("student", new Student());
        return "studentForm"; // página studentForm.html
    }

    // INSERIR nova matrícula
    @PostMapping
    public String createStudent(@Valid @ModelAttribute Student student,
                                BindingResult bindingResult,
                                @RequestParam(required = false) List<String> benefits, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("student", student);
            return "studentForm";
        }
        studentRepository.save(student);

        if (benefits != null) {
            for (String b : benefits) {
                BenefitType type = BenefitType.valueOf(b);

                // Busca benefício existente ou cria novo
                Benefit benefit = benefitRepository.findByType(type)
                        .orElseGet(() -> {
                            Benefit newBenefit = new Benefit();
                            newBenefit.setName(type.getLabel()); // usa label amigável
                            newBenefit.setType(type);
                            newBenefit.setAmount(definirValorPadrao(b));
                            return benefitRepository.save(newBenefit);
                        });

                StudentBenefit sb = new StudentBenefit();
                sb.setStudent(student);
                sb.setBenefit(benefit);
                student.getBenefits().add(sb);
            }
            studentRepository.save(student);
        }

        return "redirect:/students";
    }

    // EDITAR matrícula
    @GetMapping("/{registrationNumber}/edit")
    public String editStudentForm(@PathVariable String registrationNumber, Model model) {
        Optional<Student> studentOpt = studentRepository.findByRegistrationNumber(registrationNumber);
        if (studentOpt.isPresent()) {
            model.addAttribute("student", studentOpt.get());
            return "studentForm";
        }
        return "redirect:/students";
    }

    @PostMapping("/{registrationNumber}/edit")
    public String updateStudent(@PathVariable String registrationNumber,
                                @ModelAttribute Student student,
                                @RequestParam(required = false) List<String> benefits) {
        studentRepository.save(student);

        student.getBenefits().clear();
        if (benefits != null) {
            for (String b : benefits) {
                BenefitType type = BenefitType.valueOf(b);

                Benefit benefit = benefitRepository.findByType(type)
                        .orElseGet(() -> {
                            Benefit newBenefit = new Benefit();
                            newBenefit.setName(type.getLabel());
                            newBenefit.setType(type);
                            newBenefit.setAmount(definirValorPadrao(b));
                            return benefitRepository.save(newBenefit);
                        });

                StudentBenefit sb = new StudentBenefit();
                sb.setStudent(student);
                sb.setBenefit(benefit);
                student.getBenefits().add(sb);
            }
            studentRepository.save(student);
        }

        return "redirect:/students";
    }

    // APAGAR matrícula
    @GetMapping("/{registrationNumber}/delete")
    public String deleteStudent(@PathVariable String registrationNumber) {
        studentRepository.findByRegistrationNumber(registrationNumber)
                .ifPresent(studentRepository::delete);
        return "redirect:/students";
    }

    // Método auxiliar para definir valores padrão dos benefícios
    private double definirValorPadrao(String benefitType) {
        return switch (benefitType) {
            case "HOUSING" -> 300.0;
            case "TRANSPORT" -> 150.0;
            case "FOOD" -> 250.0;
            case "CHILDCARE" -> 400.0;
            case "LIBRARY_FINE" -> 25.0;
            case "ATHLETE" -> 200.0;
            default -> 0.0;
        };
    }
}
