package com.grantcalc.controller;

import com.grantcalc.service.GrantService;
import com.grantcalc.calculation.Grant;
import com.grantcalc.model.Student;
import com.grantcalc.repository.StudentRepository;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class GrantController {

    @Autowired
    private GrantService grantService;

    @Autowired
    private StudentRepository studentRepository;

    @GetMapping("/grant")
    public String showForm() {
        return "grantForm";
    }

    @PostMapping("/grant")
public String calculateGrant(@RequestParam String registrationNumber,
                             @RequestParam Double baseGrantAmount,
                             @RequestParam(required = false) List<String> benefits,
                             Model model) {
    // Recupera ou cria aluno
    Student student = studentRepository.findByRegistrationNumber(registrationNumber)
                                       .orElse(new Student());
    student.setRegistrationNumber(registrationNumber);
    student.setBaseGrantAmount(baseGrantAmount);

    // Atualiza benefícios
    student.getBenefits().clear();
    if (benefits != null) {
        grantService.attachBenefits(student, benefits);
    }

    // Salva no banco
    studentRepository.save(student);

    
    Grant grant = grantService.buildGrantForStudent(registrationNumber);

    model.addAttribute("student", student);
    model.addAttribute("total", grant.calculateTotal());
    model.addAttribute("description", grant.getDescription());

    return "resultado";
}

}
