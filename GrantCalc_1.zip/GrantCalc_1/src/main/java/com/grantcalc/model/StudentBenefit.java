package com.grantcalc.model;

import jakarta.persistence.*;

@Entity
public class StudentBenefit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Student student;

    @ManyToOne
    private Benefit benefit;

    // getters e setters
     public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }

    public Benefit getBenefit() { return benefit; }
    public void setBenefit(Benefit benefit) { this.benefit = benefit; }
}
