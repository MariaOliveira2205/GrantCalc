package com.grantcalc.model;

import jakarta.persistence.*; 
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.util.List;
import java.util.ArrayList;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "A matrícula é obrigatória")
    @Column(unique = true)
    private String registrationNumber;
    
    @NotNull(message = "O valor da bolsa base é obrigatório")
    @Positive(message = "O valor da bolsa base deve ser positivo")
    private double baseGrantAmount;

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL)
    private List<StudentBenefit> benefits = new ArrayList<>();

    // getters e setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRegistrationNumber() { return registrationNumber; }
    public void setRegistrationNumber(String registrationNumber) { this.registrationNumber = registrationNumber; }

    public double getBaseGrantAmount() { return baseGrantAmount; }
    public void setBaseGrantAmount(double baseGrantAmount) { this.baseGrantAmount = baseGrantAmount; }

    public List<StudentBenefit> getBenefits() { return benefits; }
    public void setBenefits(List<StudentBenefit> benefits) { this.benefits = benefits; }

}
