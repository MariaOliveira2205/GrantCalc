package com.grantcalc.model;

public enum BenefitType {
    HOUSING("Auxílio Moradia"),
    TRANSPORT("Auxílio Transporte"),
    FOOD("Auxílio Alimentação"),
    CHILDCARE("Auxílio Creche"),
    LIBRARY_FINE("Multa Biblioteca"),
    ATHLETE("Bolsa Atleta");

    private final String label;

    BenefitType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
